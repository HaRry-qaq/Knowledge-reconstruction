lex.cpp：词法分析程序
lex_flex_linux.zip：在linux环境下的lex生成的词法分析程序，其中有lex.i、lex.yy.c与a.out，a.out是linux的可执行文件
s.txt为测试的代码段，test.cpp是为了验证其能否编译成功。
若控制台中文出现乱码：控制台输入
chcp 65001
后重新执行即可。 
