gram_analysis_1.cpp
gram_analysis_2.cpp
gram_analysis_3.cpp
依次为语法分析实验题目1、2、3的代码。
输入语句形如
(1+3)/2*4
其中数字为一位，表示词法分析中经处理后得到的代表数字的文法符号。
