header Main

  uses System, Thread, Synch

  functions
    main ()

endHeader
